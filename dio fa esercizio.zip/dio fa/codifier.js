/* 
-26/03/22
-Mattia Baroni
*/

var NumInt = 0
var NumBit = 0
var LassoMax = 0

function checkNumbers(){
    NumInt = document.getElementById("num").value;
    NumBit = document.getElementById("numBit").value;

    NumBit = NumBit * 1;
    NumInt = NumInt * 1;

    LassoMax = Math.pow(2,NumBit);
    
    LassoMax = LassoMax * 1;

    if (LassoMax <= NumInt){
        document.getElementById("ProvaOut").innerHTML = "errore: il numero e' troppo grande per i bit scelti";
    }

    else{
        document.getElementById("ProvaOut").innerHTML = "numero accettato, richiamo funzione";
        
        /* inizio funzione */

    }
}


